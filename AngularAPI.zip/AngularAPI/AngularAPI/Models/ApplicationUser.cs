﻿using System;
using Microsoft.AspNetCore.Identity;

namespace AngularAPI.Models
{
	public class ApplicationUser:IdentityUser
	{
	}
}

